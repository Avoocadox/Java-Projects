package br.com.fiap.entity;

public enum Categoria {
	HISTORIA , CULTURA , PARQUES , GASTRONOMIA , VIDA_NOTURNA, ENTRETENIMENTO
}
