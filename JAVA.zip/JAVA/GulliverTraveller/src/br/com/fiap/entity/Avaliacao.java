package br.com.fiap.entity;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;


@Entity
@Table(name = "TB_AVALIACAO")
@SequenceGenerator(name = "avaliacao", sequenceName = "SQ_TB_AVALIACAO", allocationSize = 1)
public class Avaliacao {
	
	
	@Id
	@Column(name = "id_avaliacao", nullable = false, length = 9)
	private int idAvalicao;
	
	@Column(name = "ds_comentario", nullable = false, length = 500)
	private String descricao;
	
	@Column(name = "vl_nota", nullable = false, length = 4)
	private double nota;
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "dt_comentario", nullable = false, length = 50)
	private Calendar dataComentario;
	
	@Column(name = "im_fotos", nullable = false, length = 500)
	private String fotos;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "id_ponto")
	private PontoTuristico pontoTuristico;
	
	
	
	
	
	
	public Avaliacao() {}
	public Avaliacao(String descricao, double nota, Calendar dataComentario, String fotos) {
		this.descricao = descricao;
		this.nota = nota;
		this.dataComentario = dataComentario;
		this.fotos = fotos;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getNota() {
		return nota;
	}
	public void setNota(double nota) {
		this.nota = nota;
	}
	public Calendar getDataComentario() {
		return dataComentario;
	}
	public void setDataComentario(Calendar dataComentario) {
		this.dataComentario = dataComentario;
	}
	public String getFotos() {
		return fotos;
	}
	public void setFotos(String fotos) {
		this.fotos = fotos;
	}
	
	
	
	
	
}
