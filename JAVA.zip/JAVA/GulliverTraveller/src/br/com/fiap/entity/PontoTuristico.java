package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;



@Entity
@Table(name = "TB_PONTO_TURISTICO")
@SequenceGenerator(name = "ponto_turistico", sequenceName = "SQ_TB_PONTO_TURISTICO", allocationSize = 1)
public class PontoTuristico {
	
	@Id
	@Column(name = "id_ponto")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ponto_turistico")
	private int idPonto;
	
	@Column(name = "nm_ponto", nullable = false, length = 50)
	private String nomePontoTuristico;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "ds_categoria" , nullable = false , length = 30)
	private Categoria categoria;
	
	@Column(name = "im_ponto", nullable = false, length = 500)
	private String imagemPontoTuristico;
	
	@Column(name = "ds_ponto", nullable = false, length = 500)
	private String descricao;
	
	@Column(name = "ds_localizacao", nullable = false, length = 80)
	private String localizacao;
	
	@Column(name = "vl_preco" , nullable = false, length = 6)
	private double preco;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "ds_regiao", nullable = false, length = 30)
	private Regiao regiao;
	
	@Column(name = "tp_cozinha",length = 50)
	private String cozinha;
	
	
	
	
	
	
	
	
	
	
	
	public PontoTuristico() {}
	
	
	public PontoTuristico(String nomePontoTuristico, Categoria categoria, String imagemPontoTuristico, String descricao,
			String localizacao, double preco, Regiao regiao, String cozinha) {
		this.nomePontoTuristico = nomePontoTuristico;
		this.categoria = categoria;
		this.imagemPontoTuristico = imagemPontoTuristico;
		this.descricao = descricao;
		this.localizacao = localizacao;
		this.preco = preco;
		this.regiao = regiao;
		this.cozinha = cozinha;
	}
	
	
	
	public String getNomePontoTuristico() {
		return nomePontoTuristico;
	}
	public void setNomePontoTuristico(String nomePontoTuristico) {
		this.nomePontoTuristico = nomePontoTuristico;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public String getImagemPontoTuristico() {
		return imagemPontoTuristico;
	}
	public void setImagemPontoTuristico(String imagemPontoTuristico) {
		this.imagemPontoTuristico = imagemPontoTuristico;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getLocalizacao() {
		return localizacao;
	}
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public Regiao getRegiao() {
		return regiao;
	}
	public void setRegiao(Regiao regiao) {
		this.regiao = regiao;
	}
	public String getCozinha() {
		return cozinha;
	}
	public void setCozinha(String cozinha) {
		this.cozinha = cozinha;
	}
	
	
	
	
	
	
}
