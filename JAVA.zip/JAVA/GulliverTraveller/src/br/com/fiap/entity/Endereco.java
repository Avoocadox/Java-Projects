package br.com.fiap.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "TB_ENDERECO")
@SequenceGenerator(name = "endereco" , sequenceName = "SQ_TB_ENDERECO", allocationSize = 1)
public class Endereco {
	@Id
	@Column(name = "id_endereco")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "endereco")
	private int idEndereco;
	
	@Enumerated(EnumType.STRING)
	@Column(name = "nm_logradouro", nullable = false, length = 20)
	private Logradouro logradouro;
	
	@Column(name = "ds_endereco", nullable = false, length = 500)
	private String endereco;
	
	@Column(name = "nr_endereco", nullable = false, length = 5)
	private int numeroEndereco;
	
	@Column(name = "nr_cep", nullable = false, length = 8)
	private Integer numeroCep;
	
	@Column(name = "ds_bairro", nullable = false, length = 30)
	private String bairro;
	
	@Column(name = "ds_estado", nullable = false, length = 30)
	private String cidade;
	
	@Column(name = "ds_cidade", nullable = false, length = 30)
	private String estado;
	

	
	
	
	public Endereco() {}
	
	
	public Endereco(Logradouro logradouro, String endereco, int numeroEndereco, Integer numeroCep, String bairro,
			String cidade, String estado) {
		this.logradouro = logradouro;
		this.endereco = endereco;
		this.numeroEndereco = numeroEndereco;
		this.numeroCep = numeroCep;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
	}
	public Logradouro getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(Logradouro logradouro) {
		this.logradouro = logradouro;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public int getNumeroEndereco() {
		return numeroEndereco;
	}
	public void setNumeroEndereco(int numeroEndereco) {
		this.numeroEndereco = numeroEndereco;
	}
	public Integer getNumeroCep() {
		return numeroCep;
	}
	public void setNumeroCep(Integer numeroCep) {
		this.numeroCep = numeroCep;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
}
