package br.com.fiap.entity;

public enum Regiao {
	ZONA_NORTE , ZONA_OESTE, ZONA_LESTE, ZONA_SUL, CENTRO
}
