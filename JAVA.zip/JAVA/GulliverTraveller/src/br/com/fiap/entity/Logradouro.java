package br.com.fiap.entity;

public enum Logradouro {
	Rua,Avenida,Estrada,Rodovia,Beco,Viela,Alameda,Chacara,Col�nia,Condom�nio
}
