package br.com.fiap.fiap.main;

import java.util.List;

import javax.persistence.EntityManager;

import br.com.fiap.dao.PontoTuristicoDao;
import br.com.fiap.dao.impl.PontoTuristicoDaoImpl;
import br.com.fiap.entity.Categoria;
import br.com.fiap.entity.PontoTuristico;
import br.com.fiap.entity.Regiao;
import br.com.fiap.factorySingleton.EntityManagerFactorySingleton;

public class Pesquisa {
	
	public static void main(String[] args) {
		
	
	EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
	PontoTuristicoDao pontoTuristicoDao = new PontoTuristicoDaoImpl(em);
	// PESQUISA JPQL 1
	List<PontoTuristico> pontoTuristicoPorCategoria = pontoTuristicoDao.buscarPorCategoria(Categoria.GASTRONOMIA);
	System.out.println("Busca por categoria realizada com sucesso!!");
	
	 for(PontoTuristico pontoTuristico : pontoTuristicoPorCategoria) {
		 System.out.println(pontoTuristico.getNomePontoTuristico());
	 }
	
	 //PESQUISA JPQL 2
	 List<PontoTuristico> pontoTuristicoPorPreco = pontoTuristicoDao.buscarPorPreco(90.00);
		System.out.println("Busca por pre�o realizada com sucesso!!");
		 for(PontoTuristico pontoTuristico : pontoTuristicoPorPreco) {
			 System.out.println(pontoTuristico.getNomePontoTuristico());
			 System.out.println("R$ " + pontoTuristico.getPreco());		 
		 }
			
	 //PESQUISA JPQL 3
	List<PontoTuristico> pontoTuristicoPorRegiao = pontoTuristicoDao.buscarPorRegiao(Regiao.ZONA_SUL);
		System.out.println("Busca por regi�o realizada com sucesso!!");
		for(PontoTuristico pontoTuristico : pontoTuristicoPorRegiao) {
			System.out.println(pontoTuristico.getNomePontoTuristico());
			System.out.println(pontoTuristico.getLocalizacao());
		}

	 
	}
}
