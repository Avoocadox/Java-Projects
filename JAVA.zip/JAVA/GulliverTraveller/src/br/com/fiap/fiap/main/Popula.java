package br.com.fiap.fiap.main;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;

import br.com.fiap.dao.GenericDao;
import br.com.fiap.dao.impl.GenericDaoImpl;
import br.com.fiap.entity.Avaliacao;
import br.com.fiap.entity.Categoria;
import br.com.fiap.entity.Endereco;
import br.com.fiap.entity.Logradouro;
import br.com.fiap.entity.PontoTuristico;
import br.com.fiap.entity.Regiao;
import br.com.fiap.entity.Usuario;
import br.com.fiap.exceptions.CommitException;
import br.com.fiap.factorySingleton.EntityManagerFactorySingleton;

public class Popula {
	public static void main(String[] args) {
		
	
	
	EntityManager em = EntityManagerFactorySingleton.getInstance().createEntityManager();
	GenericDao<Usuario, Integer> daoUsuario = new GenericDaoImpl<Usuario, Integer>(em) {};
	Calendar nascimentoUsuario = new GregorianCalendar(1999, Calendar.OCTOBER, 14);
	Usuario usuario = new Usuario("senha123", "Gabriel", "Batista" , nascimentoUsuario,"11948693122");
	
	
	GenericDao<Endereco, Integer> daoEndereco = new GenericDaoImpl<Endereco, Integer>(em) {};
	Endereco endereco = new Endereco(Logradouro.Avenida,"Avenida Sapopemba", 926, 9250301, "Jd.Utinga", "Santo Andr�" , "S�o Paulo");
	
	
	GenericDao<PontoTuristico, Integer> daoPontoTuristico = new GenericDaoImpl<PontoTuristico, Integer>(em) {};
	PontoTuristico pontoTuristico = new PontoTuristico("Bar do Alem�o",Categoria.GASTRONOMIA, "https://images-ext-1.discordapp.net/external/uE7NTgnJ-OKAeKP5QN548UR1-Lbe-DRZl0iufN6HI9k/https/res.cloudinary.com/tf-lab/image/upload/w_600%2Ch_337%2Cc_fill%2Cg_auto%3Asubject%2Cq_auto%2Cf_auto/restaurant/3e42784d-e88d-493c-94e0-24efa3810617/105e59db-f572-47a2-91b5-1a55954cefba.jpg","� a paix�o pela boa comida, boa bebida e o conv�vio com os amigos que fazem com que o Bar do Alem�o, seja esse sucesso, seja em S�o Paulo ou em qualquer outra cidade.","Endere�o: Avenida Juriti, 651 - Moema � S�o Paulo/SP - CEP: 04520-001",90.00, Regiao.ZONA_SUL, "Buteco");
	
	
	Calendar criacaoAvaliacao = Calendar.getInstance();
	GenericDao<Avaliacao, Integer> daoAvaliacao = new GenericDaoImpl<Avaliacao, Integer>(em) {};
	Avaliacao avaliacao = new Avaliacao("Lugar muito limpo, com uma gastronomia simples por�m com otimo gosto, lugar incr�vel para curtir e se deliciar", 8.75, criacaoAvaliacao, "https://images-ext-2.discordapp.net/external/e0Vr2Q58O9IrK3tLxe9UyzSIX8e8qqNrfgUkvnC3NUg/https/res.cloudinary.com/tf-lab/image/upload/w_600%2Ch_337%2Cc_fill%2Cg_auto%3Asubject%2Cq_auto%2Cf_auto/restaurant/3e42784d-e88d-493c-94e0-24efa3810617/afd67a98-d7fb-494c-a220-4ff5a03947df.jpg");
	

	try {
		daoUsuario.create(usuario);
		daoUsuario.commit();
		System.out.println("Usuario Cadastrado!");
		daoEndereco.create(endereco);
		daoEndereco.commit();
		System.out.println("Endereco Cadastrado!");
		daoPontoTuristico.create(pontoTuristico);
		daoPontoTuristico.commit();
		System.out.println("Ponto Turistico Cadastrado!");
		daoAvaliacao.create(avaliacao);
		daoAvaliacao.commit();
		System.out.println("Avalia��o Cadastrada!");

		} catch (CommitException e) {
		System.out.println(e.getMessage());
	}
	
	em.close();
	EntityManagerFactorySingleton.getInstance().close();
	}
	
	}
