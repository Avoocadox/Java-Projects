package br.com.fiap.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.dao.PontoTuristicoDao;
import br.com.fiap.entity.Categoria;
import br.com.fiap.entity.PontoTuristico;
import br.com.fiap.entity.Regiao;

public class PontoTuristicoDaoImpl extends GenericDaoImpl<PontoTuristico, Integer> implements PontoTuristicoDao {

	public PontoTuristicoDaoImpl(EntityManager em) {
		super(em);
	}
	
	
	@Override
	public List<PontoTuristico> buscarPorCategoria(Categoria categoria){
		TypedQuery<PontoTuristico> query = em.createQuery("from PontoTuristico p where p.categoria =: tipoCategoria", PontoTuristico.class);
		query.setParameter("tipoCategoria", categoria);
		return query.getResultList();
		
	}
	
	@Override
	public List<PontoTuristico>buscarPorPreco(double preco){
		TypedQuery<PontoTuristico> query = em.createQuery("from PontoTuristico p where p.preco =:precoPonto", PontoTuristico.class);
		query.setParameter("precoPonto", preco);
		return query.getResultList();
	}


	@Override
	public List<PontoTuristico> buscarPorRegiao(Regiao regiao) {
		TypedQuery<PontoTuristico> query = em.createQuery("from PontoTuristico p where p.regiao =:regiaoPonto", PontoTuristico.class);
		query.setParameter("regiaoPonto", regiao);
		return query.getResultList();
	}


}
