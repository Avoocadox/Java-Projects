package br.com.fiap.dao;

import br.com.fiap.entity.Usuario;

public interface UsuarioDao extends GenericDao<Usuario, Integer> {

}
