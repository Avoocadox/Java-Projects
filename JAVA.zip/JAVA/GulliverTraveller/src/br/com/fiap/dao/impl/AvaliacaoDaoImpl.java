package br.com.fiap.dao.impl;



import javax.persistence.EntityManager;


import br.com.fiap.dao.AvalicaoDao;
import br.com.fiap.entity.Avaliacao;


public class AvaliacaoDaoImpl extends GenericDaoImpl<Avaliacao, Integer> implements AvalicaoDao {

	public AvaliacaoDaoImpl(EntityManager em) {
		super(em);
	}



}
