package br.com.fiap.dao;

import br.com.fiap.entity.Endereco;

public interface EnderecoDao extends GenericDao<Endereco, Integer> {

}
