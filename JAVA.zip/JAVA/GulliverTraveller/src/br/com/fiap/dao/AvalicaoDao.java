package br.com.fiap.dao;


import br.com.fiap.entity.Avaliacao;

public interface AvalicaoDao extends GenericDao<Avaliacao, Integer> {
	

	

	
}
