package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.entity.Categoria;
import br.com.fiap.entity.PontoTuristico;
import br.com.fiap.entity.Regiao;

public interface PontoTuristicoDao extends GenericDao<PontoTuristico, Integer> {
	
	List<PontoTuristico> buscarPorCategoria(Categoria categoria);
	
	List<PontoTuristico> buscarPorPreco(double preco);
	
	List<PontoTuristico> buscarPorRegiao(Regiao regiao);
	
}
